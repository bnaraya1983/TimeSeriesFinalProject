#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("DJIA Stock Price Prediction"),
    theme= shinythemes::shinytheme('simplex'),
    sidebarLayout(
      sidebarPanel(
        selectInput('Stock_Symbol', 'Select Stock',unique(all.stocks$Name)),
        dateRangeInput('date_range','Select Date',min(all.stocks$Date), max(all.stocks$Date)),
        selectInput('Frequency', 'Frequency',choices = c('Daily','Weekly', 'Monthly','Quarterly', 'Yearly')),
        selectInput('Display','Display',choices=c('Line','Candlesticks','Bar chart', 'Smoothed')),
        sliderInput('Forecast', 'Forecast Interval', min=1, max = 10, value = c(1,10)),
        radioButtons('Forecastunit', 'Forecast Interval unit',choices=c('days',"Weeks", "Months", "Quarters","Years"))

        
      ),
      mainPanel(
        tabsetPanel(
          tabPanel("Overview",plotOutput("overview")),
          tabPanel("Historical Prices",DT::DTOutput("Historical_Prices")),
          tabPanel("Decomposition",plotOutput("decomp")),
          tabPanel("Advanced Charting",),
        )        
      )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  library(tidyr)
  library(fpp3)
  all.stocks = readr::read_csv('all_stocks_2006-01-01_to_2018-01-01.csv')
  all.stocks.ts <- all.stocks %>% mutate(Date=as_date(Date)) %>% as_tsibble(key=Name,index=Date)
  #output$overview <- all.stocks.ts %>% filter(Name == input$Stock_Symbol) %>% autoplot(Close)
  
  rv_stocks <-  reactive({all.stocks.ts %>% filter(Name == input$Stock_Symbol)})
  rv_stocks_date <- reactive({rv_stocks() %>% filter(Date >= input$date_range[1],Date <= input$date_range[2])})
  
  output$overview <- renderPlot({rv_stocks_date() %>% autoplot(Close)})
  output$Historical_Prices <- DT::renderDT({rv_stocks_date()})
  output$decomp <- renderPlot({rv_stocks() %>% fill_gaps(Close = 0) %>% model(stl = STL(Close)) %>% components() %>% autoplot()})
  
  rv_fit <- reactive({rv_stocks() %>% fill_gaps(Close=0) %>%
  model(arima210 = ARIMA(Close ~ pdq(2,1,0)),
      arima013 = ARIMA(Close ~ pdq(0,1,3)),
     stepwise = ARIMA(Close),
    search = ARIMA(Close, stepwise=FALSE))})
  
  rv_forecastinterval <- reactive({dQuote(paste(input$Forecast, input$Forecastunit))})
  # 
  output$advanced <- renderPlot({rv_fit() %>% forecast (h= input$Forecast) %>% filter(.model=='search') %>% autoplot(rv_stocks()) })
  
}

# Run the application 
shinyApp(ui = ui, server = server)
